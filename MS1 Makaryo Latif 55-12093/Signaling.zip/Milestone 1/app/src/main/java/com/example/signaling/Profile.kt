package com.example.signaling

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.text.SpannableString
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.protocols.R
import com.google.firebase.auth.FirebaseAuth

class Profile : AppCompatActivity() {

    private lateinit var emailTextView: TextView
    private lateinit var usernameEditText: EditText
    private lateinit var saveButton: Button
    private lateinit var editButton: Button
    private lateinit var savedUsernameTextView: TextView
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var btngoBackButton: ImageButton

    private lateinit var mAuth: FirebaseAuth
    private var isEditing = false

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        mAuth = FirebaseAuth.getInstance()

        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)

        emailTextView = findViewById(R.id.emailTextView)
        usernameEditText = findViewById(R.id.usernameEditText)
        saveButton = findViewById(R.id.saveButton)
        editButton = findViewById(R.id.editButton)
        savedUsernameTextView = findViewById(R.id.savedUsernameTextView)
        btngoBackButton = findViewById(R.id.goBackButton4)

        btngoBackButton.setOnClickListener {
            val intent = Intent(this@Profile, endpage::class.java)
            startActivity(intent)
        }

        displayUserEmail()
        loadUsername()

        saveButton.setOnClickListener {
            saveUsername()
        }

        editButton.setOnClickListener {
            toggleEditMode()
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun displayUserEmail() {
        val user = mAuth.currentUser
        user?.let {
            val emailLabel = "User Email: "
            val emailAddress = it.email ?: "Not available"

            val spannableString = SpannableString(emailLabel + emailAddress)

            spannableString.setSpan(
                android.text.style.StyleSpan(android.graphics.Typeface.BOLD),
                0,
                emailLabel.length,
                android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )

            spannableString.setSpan(
                android.text.style.ForegroundColorSpan(resources.getColor(R.color.Red)),
                emailLabel.length,
                spannableString.length,
                android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )

            emailTextView.text = spannableString
        } ?: run {
            Toast.makeText(this, "No user is signed in", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadUsername() {
        val user = mAuth.currentUser
        user?.let {
            val userKey = user.email ?: user.uid
            val savedUsername = sharedPreferences.getString("username_$userKey", null)
            if (savedUsername != null) {
                val usernameLabel = "Username: "
                val spannableString = SpannableString(usernameLabel + savedUsername)

                spannableString.setSpan(
                    android.text.style.StyleSpan(android.graphics.Typeface.BOLD),
                    0,
                    usernameLabel.length,
                    android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )

                spannableString.setSpan(
                    android.text.style.ForegroundColorSpan(resources.getColor(R.color.Red)),
                    usernameLabel.length,
                    spannableString.length,
                    android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )

                savedUsernameTextView.text = spannableString
                usernameEditText.setText(savedUsername)
                savedUsernameTextView.visibility = View.VISIBLE
                usernameEditText.visibility = View.GONE
            } else {
                usernameEditText.visibility = View.VISIBLE
                savedUsernameTextView.visibility = View.GONE
            }
        }
    }

    private fun toggleEditMode() {
        val user = mAuth.currentUser
        user?.let {
            val userKey = user.email ?: user.uid
            val currentUsername = sharedPreferences.getString("username_$userKey", null)
            if (currentUsername != null) {
                usernameEditText.setText(currentUsername)
            }
            savedUsernameTextView.visibility = View.GONE
            usernameEditText.visibility = View.VISIBLE
        }
    }

    private fun saveUsername() {
        val user = mAuth.currentUser
        user?.let {
            val userKey = user.email ?: user.uid
            val username = usernameEditText.text.toString().trim()
            if (username.isNotEmpty()) {
                val usernameLabel = "Username: "
                val spannableString = SpannableString(usernameLabel + username)

                spannableString.setSpan(
                    android.text.style.StyleSpan(android.graphics.Typeface.BOLD), // Make it bold
                    0, // Start index
                    usernameLabel.length, // End index
                    android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )

                // Apply color to the actual username
                spannableString.setSpan(
                    android.text.style.ForegroundColorSpan(resources.getColor(R.color.Red)), // Change color to red
                    usernameLabel.length, // Start index for username
                    spannableString.length, // End index for username
                    android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )

                savedUsernameTextView.text = spannableString
                savedUsernameTextView.visibility = View.VISIBLE
                usernameEditText.visibility = View.GONE

                with(sharedPreferences.edit()) {
                    putString("username_$userKey", username)
                    apply()
                }

                Toast.makeText(this, "Username saved: $username", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Please enter a valid username", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
