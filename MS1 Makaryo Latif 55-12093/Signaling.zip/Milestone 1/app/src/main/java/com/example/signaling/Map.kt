package com.example.signaling

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.protocols.R
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class Map : AppCompatActivity(), OnMapReadyCallback {
    private var mGoogleMap: GoogleMap? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_map)

        val mapFragment =
            supportFragmentManager.findFragmentById(R.id.mapFragment) as SupportMapFragment
        mapFragment.getMapAsync(this)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mGoogleMap = googleMap

        val location1 = LatLng(29.9866889365272, 31.441966001604296)
        val location2 = LatLng(29.989319467925494, 31.44208861779862)

        mGoogleMap?.apply {
            val marker1 = addMarker(
                MarkerOptions()
                    .position(location1)
                    .title("GUC Clinic")
            )

            val marker2 = addMarker(
                MarkerOptions()
                    .position(location2)
                    .title("Drug Store")
            )
            val germanUniversityLocation = LatLng(29.988424, 31.444122)
            moveCamera(CameraUpdateFactory.newLatLngZoom(germanUniversityLocation, 15f))
        }
    }
}