package com.example.signaling

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.protocols.R

class endpage : AppCompatActivity() {

    private lateinit var btngoBackButton: ImageButton
    private lateinit var btnMap: Button
    private lateinit var btnProfile: Button

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_endpage)

        btngoBackButton = findViewById(R.id.goBackButton3)
        btngoBackButton.setOnClickListener{
            val intent = Intent(this@endpage, MainActivity::class.java)
            startActivity(intent)
        }

        btnMap = findViewById(R.id.Map)
        btnMap.setOnClickListener{
            val intent = Intent(this@endpage, Map::class.java)
            startActivity(intent)
        }

        btnProfile = findViewById(R.id.Profile)
        btnProfile.setOnClickListener{
            val intent = Intent(this@endpage, Profile::class.java)
            startActivity(intent)
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}